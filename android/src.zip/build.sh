#!/usr/bin/env bash
# Compila IL CONTO per Android con i soli strumenti dell'SDK (niente Gradle).
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -n "$SDK" ] || { echo "ANDROID_HOME non impostato"; exit 1; }
BT="$SDK/build-tools/$(ls "$SDK/build-tools" | sort -V | tail -1)"
PLAT="$SDK/platforms/android-34/android.jar"
[ -f "$PLAT" ] || PLAT="$SDK/platforms/$(ls "$SDK/platforms" | sort -V | tail -1)/android.jar"
CODE="${VERSION_CODE:-1}"
NAME="${VERSION_NAME:-1.0}"
echo "build-tools: $BT"; echo "platform: $PLAT"; echo "versione: $NAME ($CODE)"

rm -rf out && mkdir -p out/gen out/classes out/dex
"$BT/aapt2" compile --dir res -o out/res.zip
"$BT/aapt2" link -o out/base.apk -I "$PLAT" --manifest AndroidManifest.xml --java out/gen \
  --min-sdk-version 26 --target-sdk-version 34 --version-code "$CODE" --version-name "$NAME" out/res.zip
javac -source 8 -target 8 -Xlint:-options -bootclasspath "$PLAT" -classpath "$PLAT" -d out/classes \
  $(find src out/gen -name '*.java')
"$BT/d8" --release --lib "$PLAT" --min-api 26 --output out/dex $(find out/classes -name '*.class')
(cd out/dex && zip -q -j ../base.apk classes.dex)
"$BT/zipalign" -f 4 out/base.apk out/aligned.apk
# Firma: con la chiave salvata nei Secret del repository (CHIAVE_APP), così ogni
# aggiornamento si installa sopra il precedente senza perdere i dati.
KS=out/key.p12
if [ -n "${CHIAVE_APP:-}" ]; then
  echo "$CHIAVE_APP" | base64 -d > "$KS"
  echo "firma: chiave del repository"
else
  keytool -genkeypair -keystore "$KS" -storetype PKCS12 -storepass android -keypass android -alias conto \
    -keyalg RSA -keysize 2048 -validity 20000 -dname "CN=Il Conto (provvisoria)" >/dev/null 2>&1
  echo "::warning::Secret CHIAVE_APP assente: APK firmato con una chiave provvisoria, non installarlo."
fi
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:android --key-pass pass:android --ks-key-alias conto \
  --out out/il-conto.apk out/aligned.apk
rm -f "$KS"
"$BT/apksigner" verify --print-certs out/il-conto.apk | head -3
ls -la out/il-conto.apk
