package io.github.samuelgavelli.ilconto;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.util.Iterator;

/** Il ponte tra la pagina di IL CONTO e il widget. */
final class Bridge {
    private final Activity act;

    Bridge(Activity a) { act = a; }

    /** Quello che è stato toccato sul widget e l'app non ha ancora visto. Leggerlo lo consuma. */
    @JavascriptInterface
    public String drain() {
        try {
            synchronized (State.LOCK) {
                State s = State.load(act);
                JSONArray out = new JSONArray();
                Iterator<String> it = s.dirty.keys();
                while (it.hasNext()) {
                    String d = it.next();
                    JSONObject o = s.dirty.optJSONObject(d);
                    if (o == null) continue;
                    JSONObject e = new JSONObject();
                    e.put("date", d);
                    if (o.has("pell")) e.put("pell", o.optInt("pell"));
                    if (o.has("acqua")) e.put("acqua", o.optInt("acqua"));
                    out.put(e);
                }
                s.dirty = new JSONObject();
                s.save(act);
                return out.toString();
            }
        } catch (Exception e) {
            return "[]";
        }
    }

    /** L'app dice al widget com'è la giornata di oggi. */
    @JavascriptInterface
    public void push(String json) {
        try {
            JSONObject j = new JSONObject(json);
            synchronized (State.LOCK) {
                State s = State.load(act);
                if (s.date.equals(j.optString("date"))) {
                    if (!s.isDirty("pell")) s.setPell(j.optInt("pell", 0));
                    if (!s.isDirty("acqua")) s.acqua = Math.max(0, Math.min(State.WMAX, j.optInt("acqua", 0)));
                }
                s.goal = Math.max(State.GLASS, j.optInt("goal", s.goal));
                s.min = Math.max(0, j.optInt("min", s.min));
                s.save(act);
            }
            HandsWidget.refreshAll(act);
        } catch (Exception e) { /* niente */ }
    }

    @JavascriptInterface
    public boolean copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("IL CONTO", text));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Salva il backup nella cartella Download del telefono. */
    @JavascriptInterface
    public boolean saveFile(String name, String text) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                Uri u = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return false;
                OutputStream os = act.getContentResolver().openOutputStream(u);
                if (os == null) return false;
                os.write(text.getBytes("UTF-8"));
                os.close();
                act.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(act, "Backup salvato in Download", Toast.LENGTH_SHORT).show();
                    }
                });
                return true;
            }
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, name);
            i.putExtra(Intent.EXTRA_TEXT, text);
            act.startActivity(Intent.createChooser(i, "Salva il backup"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public int version() { return 1; }
}
