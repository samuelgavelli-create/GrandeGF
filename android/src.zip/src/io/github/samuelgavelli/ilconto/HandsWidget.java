package io.github.samuelgavelli.ilconto;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.Locale;

/** Due mani e un bicchiere sulla schermata home: un tocco e la pellicina (o l'acqua) è segnata. */
public class HandsWidget extends AppWidgetProvider {
    static final String A_FINGER = "io.github.samuelgavelli.ilconto.FINGER";
    static final String A_WADD = "io.github.samuelgavelli.ilconto.WADD";
    static final String A_WSUB = "io.github.samuelgavelli.ilconto.WSUB";
    static final String A_TICK = "io.github.samuelgavelli.ilconto.TICK";

    private static final int[] FINGER_IDS = {R.id.f0, R.id.f1, R.id.f2, R.id.f3, R.id.f4,
            R.id.f5, R.id.f6, R.id.f7, R.id.f8, R.id.f9};

    /* stesse proporzioni del layout: testata 15%, mani 78%, acqua 22% */
    private static final float HEAD = 0.15f, HANDS = 0.78f, WADD = 0.72f;

    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (A_FINGER.equals(a) || A_WADD.equals(a) || A_WSUB.equals(a)) {
            synchronized (State.LOCK) {
                State s = State.load(c);
                if (A_FINGER.equals(a)) s.toggleFinger(in.getIntExtra("i", -1));
                else s.addWater(A_WADD.equals(a) ? State.GLASS : -State.GLASS);
                s.save(c);
            }
            buzz(c);
            refreshAll(c);
        } else if (A_TICK.equals(a)) {
            refreshAll(c);
            scheduleMidnight(c);
        } else {
            super.onReceive(c, in);
        }
    }

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) draw(c, m, id);
        scheduleMidnight(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle opts) {
        draw(c, m, id);
    }

    @Override
    public void onDisabled(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi(c, A_TICK, 0));
    }

    static void refreshAll(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, HandsWidget.class));
            for (int id : ids) draw(c, m, id);
        } catch (Exception e) { /* il widget non è in home */ }
    }

    private static void buzz(Context c) {
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE));
        } catch (Exception e) { /* niente vibrazione */ }
    }

    /* a mezzanotte le mani tornano sane e il bicchiere vuoto */
    private static void scheduleMidnight(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Calendar k = Calendar.getInstance();
            k.add(Calendar.DAY_OF_YEAR, 1);
            k.set(Calendar.HOUR_OF_DAY, 0); k.set(Calendar.MINUTE, 0);
            k.set(Calendar.SECOND, 5); k.set(Calendar.MILLISECOND, 0);
            am.set(AlarmManager.RTC, k.getTimeInMillis(), pi(c, A_TICK, 0));
        } catch (Exception e) { /* resta l'aggiornamento periodico */ }
    }

    private static PendingIntent pi(Context c, String action, int i) {
        Intent in = new Intent(c, HandsWidget.class);
        in.setAction(action);
        in.setData(Uri.parse("conto://widget/" + action + "/" + i));
        in.putExtra("i", i);
        return PendingIntent.getBroadcast(c, 0, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void draw(Context c, AppWidgetManager m, int id) {
        State s;
        synchronized (State.LOCK) { s = State.load(c); }

        float dp = c.getResources().getDisplayMetrics().density;
        Bundle o = m.getAppWidgetOptions(id);
        boolean land = c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        int wDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wDp <= 0) wDp = 320;
        if (hDp <= 0) hDp = 200;
        float w = wDp * dp, h = hDp * dp;
        float k = Math.min(1f, 1100f / Math.max(w, h));
        int W = Math.max(200, Math.round(w * k)), H = Math.max(120, Math.round(h * k));

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
        rv.setImageViewBitmap(R.id.img, render(c, s, W, H, dp * k));
        for (int i = 0; i < 10; i++) rv.setOnClickPendingIntent(FINGER_IDS[i], pi(c, A_FINGER, i));
        rv.setOnClickPendingIntent(R.id.wadd, pi(c, A_WADD, 0));
        rv.setOnClickPendingIntent(R.id.wsub, pi(c, A_WSUB, 0));
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        rv.setOnClickPendingIntent(R.id.open,
                PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(id, rv);
    }

    private static String litres(int ml) {
        String t = String.format(Locale.ITALY, "%.2f", ml / 1000f);
        while (t.endsWith("0")) t = t.substring(0, t.length() - 1);
        if (t.endsWith(",") || t.endsWith(".")) t = t.substring(0, t.length() - 1);
        return t + " L";
    }

    static Bitmap render(Context c, State s, int W, int H, float dp) {
        Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        int n = s.pell();
        boolean beer = s.acqua >= s.goal;

        /* scheda */
        float r = 22 * dp, bw = 1.5f * dp;
        RectF card = new RectF(bw, bw, W - bw, H - bw);
        Path clip = new Path();
        clip.addRoundRect(card, r, r, Path.Direction.CW);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xF50A0B10);
        cv.drawRoundRect(card, r, r, p);

        float headH = H * HEAD, mainTop = headH, mainH = H - headH;
        float handsW = W * HANDS;

        cv.save();
        cv.clipPath(clip);

        /* testata */
        p.setColor(0xFF12141C);
        cv.drawRect(0, 0, W, headH, p);
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        float ts = Math.min(headH * 0.50f, 15 * dp);
        p.setTextSize(ts);
        float base = headH / 2f + ts * 0.36f;
        p.setTextAlign(Paint.Align.LEFT);
        p.setColor(0xFFFFC94D);
        cv.drawText("IL CONTO", 14 * dp, base, p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(n > 0 ? 0xFFFF4D5E : 0xFF4DFFA6);
        cv.drawText(n == 0 ? "mani sane" : (n == 1 ? "1 dito" : n + " dita"), handsW * 0.60f, base, p);
        p.setColor(beer ? 0xFFFFC22E : 0xFF54D8FF);
        cv.drawText(litres(s.acqua), handsW + (W - handsW) / 2f, base, p);

        /* mani: una colonna per dito, presa dal foglio sano o da quello spelato */
        Bitmap ok = BitmapFactory.decodeResource(c.getResources(), R.drawable.hands_ok);
        Bitmap bad = n > 0 ? BitmapFactory.decodeResource(c.getResources(), R.drawable.hands_peeled) : null;
        int sw = ok.getWidth(), sh = ok.getHeight();
        float scale = handsW / sw;
        float srcH = mainH / scale;
        float top = mainTop + 4 * dp, bottom = H;
        if (srcH > sh) { srcH = sh; top = H - sh * scale; }
        else if (srcH < sh * 0.84f) srcH = sh * 0.84f;
        Rect src = new Rect();
        RectF dst = new RectF();
        for (int i = 0; i < 10; i++) {
            boolean peeled = (s.mask & (1 << i)) != 0;
            src.set(Math.round(i * sw / 10f), 0, Math.round((i + 1) * sw / 10f), Math.round(srcH));
            dst.set(i * handsW / 10f, top, (i + 1) * handsW / 10f, bottom);
            cv.drawBitmap(peeled && bad != null ? bad : ok, src, dst, p);
        }

        /* acqua */
        float zx = handsW, zw = W - handsW;
        p.setColor(0x14FFFFFF);
        cv.drawRect(zx, mainTop, zx + 1 * dp, H, p);
        float addH = mainH * WADD;
        float gw = zw * 0.64f, gh = Math.min(gw * 2f, addH * 0.86f);
        gw = Math.min(gw, gh / 1.6f);
        float gx = zx + (zw - gw) / 2f, gy = mainTop + (addH - gh) / 2f + 2 * dp;
        RectF g = new RectF(gx, gy, gx + gw, gy + gh);
        Bitmap empty = BitmapFactory.decodeResource(c.getResources(), R.drawable.glass_empty);
        cv.drawBitmap(empty, null, g, p);
        float f = Math.max(0f, Math.min(1f, s.acqua / (float) s.goal));
        if (f > 0) {
            Bitmap full = BitmapFactory.decodeResource(c.getResources(), beer ? R.drawable.glass_beer : R.drawable.glass_water);
            /* nel disegno il liquido va da y=70 (pieno) a y=574 su 600 */
            float cut = (574f - f * 504f) / 600f;
            cv.save();
            cv.clipRect(g.left, g.top + g.height() * cut, g.right, g.bottom);
            cv.drawBitmap(full, null, g, p);
            cv.restore();
        }
        /* la tacca del minimo: sotto, a fine giornata scatta la penale */
        if (s.min > 0 && s.min < s.goal && s.acqua < s.min) {
            float my = g.top + g.height() * (574f - (s.min / (float) s.goal) * 504f) / 600f;
            p.setColor(0xFFFF4D5E);
            p.setStrokeWidth(2 * dp);
            cv.drawLine(g.left + gw * 0.12f, my, g.right - gw * 0.12f, my, p);
        }
        /* numero di bicchieri */
        int glasses = Math.round(s.acqua / (float) State.GLASS);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(Math.min(gw * 0.52f, 26 * dp));
        p.setColor(0xFFFFFFFF);
        p.setShadowLayer(4 * dp, 0, 0, 0xCC000000);
        cv.drawText(String.valueOf(glasses), g.centerX(), g.centerY() + p.getTextSize() * 0.36f, p);
        p.clearShadowLayer();

        /* tasto -1 */
        float sy = mainTop + addH, sH = H - sy;
        float ph = Math.min(sH * 0.62f, 30 * dp), pw = Math.min(zw * 0.70f, ph * 2.2f);
        RectF pill = new RectF(zx + (zw - pw) / 2f, sy + (sH - ph) / 2f - 2 * dp, zx + (zw + pw) / 2f, sy + (sH + ph) / 2f - 2 * dp);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1A1D28);
        cv.drawRoundRect(pill, ph / 2f, ph / 2f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * dp);
        p.setColor(0x6654D8FF);
        cv.drawRoundRect(pill, ph / 2f, ph / 2f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF9FB4C4);
        p.setTextSize(ph * 0.58f);
        cv.drawText("−1", pill.centerX(), pill.centerY() + p.getTextSize() * 0.36f, p);

        cv.restore();

        /* bordo: rosso se oggi c'è sangue */
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(bw);
        p.setColor(n > 0 ? 0x99FF4D5E : 0x55FFC94D);
        cv.drawRoundRect(card, r, r, p);
        return bmp;
    }
}
