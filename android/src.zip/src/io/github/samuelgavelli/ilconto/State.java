package io.github.samuelgavelli.ilconto;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Quello che il widget sa della giornata: dita spelate, acqua bevuta, e cosa deve ancora passare all'app. */
final class State {
    static final Object LOCK = new Object();
    static final int GLASS = 250, WMAX = 6000;
    /* ordine in cui si spelano le dita quando il numero arriva dall'app */
    private static final int[] ORDER = {3, 6, 2, 7, 1, 8, 4, 5, 0, 9};

    String date = "";
    int mask, acqua, goal = 2000, min = 1000;
    JSONObject dirty = new JSONObject();

    static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    static State load(Context c) {
        SharedPreferences p = c.getSharedPreferences("conto_widget", Context.MODE_PRIVATE);
        State s = new State();
        s.date = p.getString("date", "");
        s.mask = p.getInt("mask", 0) & 0x3FF;
        s.acqua = p.getInt("acqua", 0);
        s.goal = Math.max(GLASS, p.getInt("goal", 2000));
        s.min = Math.max(0, p.getInt("min", 1000));
        try {
            s.dirty = new JSONObject(p.getString("dirty", "{}"));
        } catch (JSONException e) {
            s.dirty = new JSONObject();
        }
        String t = today();
        if (!t.equals(s.date)) { s.date = t; s.mask = 0; s.acqua = 0; }
        return s;
    }

    void save(Context c) {
        c.getSharedPreferences("conto_widget", Context.MODE_PRIVATE).edit()
                .putString("date", date).putInt("mask", mask).putInt("acqua", acqua)
                .putInt("goal", goal).putInt("min", min)
                .putString("dirty", dirty.toString()).commit();
    }

    int pell() { return Integer.bitCount(mask); }

    void setPell(int n) {
        n = Math.max(0, Math.min(10, n));
        for (int i = 0; i < ORDER.length && pell() < n; i++) mask |= (1 << ORDER[i]);
        for (int i = ORDER.length - 1; i >= 0 && pell() > n; i--) mask &= ~(1 << ORDER[i]);
    }

    void toggleFinger(int i) {
        if (i < 0 || i > 9) return;
        mask ^= (1 << i);
        mark("pell", pell());
    }

    void addWater(int ml) {
        int now = Math.max(0, Math.min(WMAX, acqua + ml));
        if (now == acqua) return;
        acqua = now;
        mark("acqua", acqua);
    }

    private void mark(String key, int v) {
        try {
            JSONObject o = dirty.optJSONObject(date);
            if (o == null) { o = new JSONObject(); dirty.put(date, o); }
            o.put(key, v);
        } catch (JSONException e) { /* niente */ }
    }

    boolean isDirty(String key) {
        JSONObject o = dirty.optJSONObject(date);
        return o != null && o.has(key);
    }
}
